<?php

$conn = mysql_connect("localhost", "root", "bufefe14") or die("impossible de trouver localhot");
mysql_select_db("web2", $conn) or die("Errer de la connexion à la base de donnée");

