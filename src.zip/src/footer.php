
                                                        </div>
                                                        <div class="col-lg-1">
                                                           
                                                        </div>
                                                    </div>

                                                    <hr/>
                                                    <footer class="" style="text-align: center">
                                                        
                                                        <pre>  <a>Contactez-nous</a></pre>
                                                        <a href="#">&copy; web 2.0</a> 2014,tous droits réservés
                                                    </footer> 
                                                </div> <!-- /container -->
                                                <script type="text/javascript" src="js/bootstrap.min.js"></script>
                                                    </script>
                                                </body>
                                            </html>
